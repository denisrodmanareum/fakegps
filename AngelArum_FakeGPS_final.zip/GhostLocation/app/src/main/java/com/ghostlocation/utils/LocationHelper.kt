package com.ghostlocation.utils

import android.content.Context
import android.location.Geocoder
import android.location.LocationManager
import android.os.Build
import com.ghostlocation.data.GhostLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.math.*

object LocationHelper {

    // ── 실제 현재 위치 가져오기 ────────────────
    fun getRealLocation(context: Context): GhostLocation? {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = listOf(
                LocationManager.GPS_PROVIDER,
                LocationManager.NETWORK_PROVIDER,
                LocationManager.PASSIVE_PROVIDER
            )
            var best: android.location.Location? = null
            for (provider in providers) {
                try {
                    @Suppress("MissingPermission")
                    val loc = lm.getLastKnownLocation(provider) ?: continue
                    if (best == null || loc.accuracy < best.accuracy) {
                        best = loc
                    }
                } catch (_: Exception) {}
            }
            best?.let {
                GhostLocation(
                    name = "내 실제 위치",
                    latitude = it.latitude,
                    longitude = it.longitude,
                    altitude = it.altitude
                )
            }
        } catch (e: Exception) { null }
    }

    // ── 주소/장소명 → 좌표 (지오코딩) ──────────
    suspend fun searchAddress(context: Context, query: String): List<GhostLocation> {
        return withContext(Dispatchers.IO) {
            try {
                val geocoder = Geocoder(context)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    suspendCancellableCoroutine { cont ->
                        geocoder.getFromLocationName(query, 5) { addresses ->
                            val results = addresses.mapIndexed { i, addr ->
                                GhostLocation(
                                    name = addr.getAddressLine(0) ?: addr.featureName ?: query,
                                    latitude = addr.latitude,
                                    longitude = addr.longitude
                                )
                            }
                            cont.resume(results)
                        }
                    }
                } else {
                    @Suppress("DEPRECATION")
                    val addresses = geocoder.getFromLocationName(query, 5) ?: emptyList()
                    addresses.map { addr ->
                        GhostLocation(
                            name = addr.getAddressLine(0) ?: addr.featureName ?: query,
                            latitude = addr.latitude,
                            longitude = addr.longitude
                        )
                    }
                }
            } catch (e: Exception) { emptyList() }
        }
    }

    // ── 랜덤 위치 생성 ─────────────────────────
    fun randomLocation(): GhostLocation {
        val lat = (-60..70).random().toDouble() + Math.random()
        val lng = (-170..170).random().toDouble() + Math.random()
        return GhostLocation(
            name = "랜덤 위치 (${String.format("%.2f", lat)}, ${String.format("%.2f", lng)})",
            latitude = lat,
            longitude = lng
        )
    }

    // ── 반경 내 랜덤 워킹 포인트 생성 ───────────
    /** center 기준 radiusMeters 반경 내에서 steps개의 랜덤 워킹 경로 생성 */
    fun generateRandomWalk(
        centerLat: Double,
        centerLng: Double,
        radiusMeters: Double = 500.0,
        steps: Int = 10
    ): List<Pair<Double, Double>> {
        val points = mutableListOf<Pair<Double, Double>>()
        var curLat = centerLat
        var curLng = centerLng

        repeat(steps) {
            val angle = Math.random() * 2 * PI
            val dist = Math.random() * (radiusMeters / 3) // 한 스텝 최대 거리
            val deltaLat = (dist * cos(angle)) / 111320.0
            val deltaLng = (dist * sin(angle)) / (111320.0 * cos(Math.toRadians(curLat)))

            val newLat = (curLat + deltaLat).coerceIn(centerLat - radiusMeters / 111320.0, centerLat + radiusMeters / 111320.0)
            val newLng = (curLng + deltaLng).coerceIn(centerLng - radiusMeters / 111320.0, centerLng + radiusMeters / 111320.0)

            curLat = newLat
            curLng = newLng
            points.add(Pair(newLat, newLng))
        }
        return points
    }

    // ── 두 좌표 간 거리 (미터) ─────────────────
    fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371000.0
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val dPhi = Math.toRadians(lat2 - lat1)
        val dLambda = Math.toRadians(lng2 - lng1)
        val a = sin(dPhi / 2).pow(2) + cos(phi1) * cos(phi2) * sin(dLambda / 2).pow(2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    // ── 시간 포맷 ────────────────────────────
    fun formatTimestamp(ts: Long): String {
        val sdf = java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(ts))
    }
}
