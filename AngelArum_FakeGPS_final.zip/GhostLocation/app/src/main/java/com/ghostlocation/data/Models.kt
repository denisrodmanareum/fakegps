package com.ghostlocation.data

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

// ─────────────────────────────────────────────
//  핵심 데이터 모델
// ─────────────────────────────────────────────

/** 위치 좌표 + 이름 */
data class GhostLocation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val altitude: Double = 0.0
)

/** 이동 경로 포인트 */
data class RoutePoint(
    val latitude: Double,
    val longitude: Double,
    val delayMs: Long = 1000L
)

/** 히스토리 항목 */
data class HistoryEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long = System.currentTimeMillis()
)

/** 이동 속도 프리셋 */
enum class MovementSpeed(val label: String, val intervalMs: Long) {
    WALK("도보 (5km/h)", 2000L),
    BIKE("자전거 (20km/h)", 800L),
    CAR("자동차 (60km/h)", 300L),
    FAST("고속 (120km/h)", 150L)
}

/** 자동 해제 타이머 */
enum class AutoStopTimer(val label: String, val minutes: Int) {
    OFF("OFF", 0),
    MIN_5("5분", 5),
    MIN_15("15분", 15),
    MIN_30("30분", 30),
    HOUR_1("1시간", 60)
}

// ─────────────────────────────────────────────
//  JSON 직렬화 헬퍼
// ─────────────────────────────────────────────
object JsonHelper {
    private val gson = Gson()

    fun locationsToJson(list: List<GhostLocation>): String = gson.toJson(list)
    fun jsonToLocations(json: String): List<GhostLocation> {
        val type = object : TypeToken<List<GhostLocation>>() {}.type
        return try { gson.fromJson(json, type) } catch (e: Exception) { emptyList() }
    }

    fun historyToJson(list: List<HistoryEntry>): String = gson.toJson(list)
    fun jsonToHistory(json: String): List<HistoryEntry> {
        val type = object : TypeToken<List<HistoryEntry>>() {}.type
        return try { gson.fromJson(json, type) } catch (e: Exception) { emptyList() }
    }
}
