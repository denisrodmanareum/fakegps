package com.ghostlocation.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.ghostlocation.data.GhostLocation
import com.ghostlocation.ui.MainUiState
import com.ghostlocation.ui.MainViewModel
import com.ghostlocation.ui.components.*
import com.ghostlocation.ui.theme.GhostColors

@Composable
fun FavoritesScreen(
    uiState: MainUiState,
    viewModel: MainViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GhostColors.BgDeep)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        ScanlineHeader(
            title = "즐겨찾기",
            subtitle = "${uiState.favorites.size}개의 저장된 위치"
        )

        if (uiState.favorites.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("⭐", fontSize = 48.sp)
                    Text(
                        text = "저장된 즐겨찾기가 없습니다",
                        color = GhostColors.TextMuted,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "지도에서 위치를 선택하고 ★ 버튼으로 저장하세요",
                        color = GhostColors.TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(uiState.favorites, key = { it.id }) { loc ->
                    FavoriteItem(
                        location = loc,
                        isActive = uiState.isMocking && uiState.currentLocation?.id == loc.id,
                        onSelect = { viewModel.selectFavorite(loc) },
                        onDelete = { viewModel.deleteFavorite(loc.id) },
                        onStartMock = {
                            viewModel.selectFavorite(loc)
                            viewModel.startMocking()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun FavoriteItem(
    location: GhostLocation,
    isActive: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
    onStartMock: () -> Unit
) {
    val cardColor = if (isActive) GhostColors.NeonGreen else GhostColors.Amber

    NeonCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = cardColor
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // 좌측: 아이콘 + 정보
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // 아이콘
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(cardColor.copy(0.15f), RoundedCornerShape(8.dp))
                        .border(1.dp, cardColor.copy(0.4f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (isActive) Icons.Default.Wifi else Icons.Default.Star,
                        contentDescription = null,
                        tint = cardColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // 이름 + 좌표
                Column {
                    Text(
                        text = location.name,
                        fontWeight = FontWeight.Bold,
                        color = GhostColors.TextPrimary,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    CoordChip(location.latitude, location.longitude)
                    if (isActive) {
                        Spacer(Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PulsingDot(isActive = true)
                            Text(
                                "변조 활성 중",
                                fontSize = 10.sp,
                                color = GhostColors.NeonGreen,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }

            // 우측: 버튼들
            Column(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                horizontalAlignment = Alignment.End
            ) {
                // 선택 버튼
                IconButton(
                    onClick = onSelect,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.LocationOn,
                        contentDescription = "선택",
                        tint = GhostColors.Cyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
                // 즉시 변조 버튼
                IconButton(
                    onClick = onStartMock,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = "바로 시작",
                        tint = GhostColors.NeonGreen,
                        modifier = Modifier.size(18.dp)
                    )
                }
                // 삭제
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "삭제",
                        tint = GhostColors.TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
