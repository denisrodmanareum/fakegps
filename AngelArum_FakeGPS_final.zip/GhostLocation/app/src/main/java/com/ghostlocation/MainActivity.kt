package com.ghostlocation

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.ghostlocation.ui.*
import com.ghostlocation.ui.screens.*
import com.ghostlocation.ui.theme.*
import com.google.accompanist.permissions.*

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent { GhostLocationTheme { GhostApp(viewModel = viewModel) } }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun GhostApp(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val locationPermission = rememberPermissionState(Manifest.permission.ACCESS_FINE_LOCATION)

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let {
            snackbarHostState.showSnackbar(it, duration = SnackbarDuration.Short)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        containerColor = GhostColors.BgDeep,
        snackbarHost = {
            SnackbarHost(snackbarHostState) { data ->
                Snackbar(snackbarData = data, containerColor = GhostColors.BgElevated,
                    contentColor = GhostColors.TextPrimary, actionColor = GhostColors.Cyan,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.border(1.dp, GhostColors.Cyan.copy(0.4f), RoundedCornerShape(8.dp)))
            }
        },
        topBar = { GhostTopBar(isMocking = uiState.isMocking, timerSeconds = uiState.timerRemainingSeconds) },
        bottomBar = { GhostBottomNav(selectedTab = uiState.selectedTab, onTabSelected = { viewModel.selectTab(it) }) }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (!locationPermission.status.isGranted) {
                PermissionScreen(onRequest = { locationPermission.launchPermissionRequest() })
            } else {
                AnimatedContent(targetState = uiState.selectedTab, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "tab") { tab ->
                    when (tab) {
                        AppTab.MAP       -> MapScreen(uiState, viewModel)
                        AppTab.ROUTE     -> RouteScreen(uiState, viewModel)
                        AppTab.FAVORITES -> FavoritesScreen(uiState, viewModel)
                        AppTab.HISTORY   -> HistoryScreen(uiState, viewModel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GhostTopBar(isMocking: Boolean, timerSeconds: Int) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("👻", fontSize = 20.sp)
                Column {
                    Text("ANGEL AREUM", fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 15.sp, color = GhostColors.Cyan)
                    val sub = when {
                        timerSeconds > 0 -> {
                            val m = timerSeconds / 60; val s = timerSeconds % 60
                            "AUTO STOP ${if (m > 0) "${m}분 " else ""}${s}초"
                        }
                        isMocking -> "GPS SPOOFING ACTIVE"
                        else -> "STANDBY"
                    }
                    Text(sub, fontSize = 9.sp, letterSpacing = 2.sp,
                        color = if (timerSeconds > 0) GhostColors.Amber else if (isMocking) GhostColors.NeonGreen else GhostColors.TextMuted)
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = GhostColors.BgSurface, titleContentColor = GhostColors.TextPrimary)
    )
}

@Composable
fun GhostBottomNav(selectedTab: AppTab, onTabSelected: (AppTab) -> Unit) {
    data class NavItem(val tab: AppTab, val icon: ImageVector, val label: String)
    val items = listOf(
        NavItem(AppTab.MAP,       Icons.Default.Map,         "지도"),
        NavItem(AppTab.ROUTE,     Icons.Default.Route,       "경로"),
        NavItem(AppTab.FAVORITES, Icons.Default.Star,        "즐겨찾기"),
        NavItem(AppTab.HISTORY,   Icons.Default.History,     "히스토리")
    )
    NavigationBar(
        containerColor = GhostColors.BgSurface,
        modifier = Modifier.drawBehind {
            drawLine(GhostColors.Border, Offset(0f, 0f), Offset(size.width, 0f), 1.dp.toPx())
        }
    ) {
        items.forEach { item ->
            val isSelected = selectedTab == item.tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(item.tab) },
                icon = { Icon(item.icon, contentDescription = item.label, modifier = Modifier.size(22.dp)) },
                label = { Text(item.label, fontSize = 10.sp, letterSpacing = 0.3.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = GhostColors.Cyan, selectedTextColor = GhostColors.Cyan,
                    unselectedIconColor = GhostColors.TextMuted, unselectedTextColor = GhostColors.TextMuted,
                    indicatorColor = GhostColors.CyanGlow
                )
            )
        }
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(GhostColors.BgDeep).padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("📍", fontSize = 64.sp)
        Spacer(Modifier.height(24.dp))
        Text("위치 권한 필요", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = GhostColors.TextPrimary, letterSpacing = 1.sp)
        Spacer(Modifier.height(12.dp))
        Text("GPS 위치 변조를 위해\n위치 접근 권한이 필요합니다", color = GhostColors.TextSecond, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp)
        Spacer(Modifier.height(32.dp))
        com.ghostlocation.ui.components.CyberButton(text = "권한 허용", onClick = onRequest, color = GhostColors.Cyan)
        Spacer(Modifier.height(24.dp))
        Text(
            "⚠  설정 → 개발자 옵션 → 모의 위치 앱\n에서 Ghost Location을 선택해야 작동합니다",
            fontSize = 11.sp, color = GhostColors.Amber, textAlign = TextAlign.Center, lineHeight = 18.sp,
            modifier = Modifier.background(GhostColors.Amber.copy(0.08f), RoundedCornerShape(8.dp)).padding(12.dp)
        )
    }
}
