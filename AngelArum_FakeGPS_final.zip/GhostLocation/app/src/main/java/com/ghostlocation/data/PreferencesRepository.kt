package com.ghostlocation.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ghost_prefs")

class PreferencesRepository(private val context: Context) {

    companion object {
        private val KEY_FAVORITES    = stringPreferencesKey("favorites")
        private val KEY_LAST_LOCATION = stringPreferencesKey("last_location")
        private val KEY_HISTORY      = stringPreferencesKey("history")
        private const val MAX_HISTORY = 30
    }

    // ── 즐겨찾기 ──────────────────────────────
    val favoritesFlow: Flow<List<GhostLocation>> = context.dataStore.data.map { prefs ->
        JsonHelper.jsonToLocations(prefs[KEY_FAVORITES] ?: "[]")
    }

    suspend fun saveFavorite(location: GhostLocation) {
        context.dataStore.edit { prefs ->
            val current = JsonHelper.jsonToLocations(prefs[KEY_FAVORITES] ?: "[]").toMutableList()
            current.removeAll { it.id == location.id }
            current.add(0, location)
            prefs[KEY_FAVORITES] = JsonHelper.locationsToJson(current)
        }
    }

    suspend fun deleteFavorite(id: String) {
        context.dataStore.edit { prefs ->
            val current = JsonHelper.jsonToLocations(prefs[KEY_FAVORITES] ?: "[]").toMutableList()
            current.removeAll { it.id == id }
            prefs[KEY_FAVORITES] = JsonHelper.locationsToJson(current)
        }
    }

    // ── 마지막 위치 ────────────────────────────
    val lastLocationFlow: Flow<GhostLocation?> = context.dataStore.data.map { prefs ->
        val json = prefs[KEY_LAST_LOCATION] ?: return@map null
        try { com.google.gson.Gson().fromJson(json, GhostLocation::class.java) } catch (e: Exception) { null }
    }

    suspend fun saveLastLocation(location: GhostLocation) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_LOCATION] = com.google.gson.Gson().toJson(location)
        }
    }

    // ── 히스토리 ──────────────────────────────
    val historyFlow: Flow<List<HistoryEntry>> = context.dataStore.data.map { prefs ->
        JsonHelper.jsonToHistory(prefs[KEY_HISTORY] ?: "[]")
    }

    suspend fun addHistory(entry: HistoryEntry) {
        context.dataStore.edit { prefs ->
            val current = JsonHelper.jsonToHistory(prefs[KEY_HISTORY] ?: "[]").toMutableList()
            current.removeAll { it.id == entry.id }
            current.add(0, entry)
            if (current.size > MAX_HISTORY) current.subList(MAX_HISTORY, current.size).clear()
            prefs[KEY_HISTORY] = JsonHelper.historyToJson(current)
        }
    }

    suspend fun clearHistory() {
        context.dataStore.edit { prefs -> prefs[KEY_HISTORY] = "[]" }
    }
}
