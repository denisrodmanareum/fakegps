package com.ghostlocation.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.*
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import com.ghostlocation.MainActivity
import com.ghostlocation.data.GhostLocation
import com.ghostlocation.data.RoutePoint
import kotlinx.coroutines.*

class MockLocationService : Service() {

    companion object {
        const val CHANNEL_ID = "ghost_location_channel"
        const val NOTIFICATION_ID = 1337
        const val TAG = "GhostLocation"

        // Intent actions
        const val ACTION_START_MOCK    = "START_MOCK"
        const val ACTION_STOP_MOCK     = "STOP_MOCK"
        const val ACTION_START_ROUTE   = "START_ROUTE"
        const val ACTION_STOP_ROUTE    = "STOP_ROUTE"
        const val ACTION_SET_LOCATION  = "SET_LOCATION"

        // Extra keys
        const val EXTRA_LAT       = "lat"
        const val EXTRA_LNG       = "lng"
        const val EXTRA_ALT       = "alt"
        const val EXTRA_NAME      = "name"
        const val EXTRA_ROUTE_JSON = "route_json"
        const val EXTRA_SPEED_MS  = "speed_ms"

        // Broadcast
        const val BROADCAST_STATUS = "com.ghostlocation.STATUS"
        const val EXTRA_IS_ACTIVE  = "is_active"
        const val EXTRA_CURRENT_LAT = "current_lat"
        const val EXTRA_CURRENT_LNG = "current_lng"

        // 편의 함수: 서비스 시작
        fun startMock(context: Context, location: GhostLocation) {
            val intent = Intent(context, MockLocationService::class.java).apply {
                action = ACTION_START_MOCK
                putExtra(EXTRA_LAT, location.latitude)
                putExtra(EXTRA_LNG, location.longitude)
                putExtra(EXTRA_ALT, location.altitude)
                putExtra(EXTRA_NAME, location.name)
            }
            context.startForegroundService(intent)
        }

        fun stopMock(context: Context) {
            val intent = Intent(context, MockLocationService::class.java).apply {
                action = ACTION_STOP_MOCK
            }
            context.startService(intent)
        }
    }

    // ─────────────────────────────────────────
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var mockJob: Job? = null
    private var routeJob: Job? = null

    private lateinit var locationManager: LocationManager
    private val providers = listOf(
        LocationManager.GPS_PROVIDER,
        LocationManager.NETWORK_PROVIDER
    )

    private var currentLat = 37.5665   // 서울 시청 기본값
    private var currentLng = 126.9780
    private var currentAlt = 30.0
    private var isActive = false

    // ─────────────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_MOCK -> {
                val lat = intent.getDoubleExtra(EXTRA_LAT, 37.5665)
                val lng = intent.getDoubleExtra(EXTRA_LNG, 126.9780)
                val alt = intent.getDoubleExtra(EXTRA_ALT, 30.0)
                val name = intent.getStringExtra(EXTRA_NAME) ?: "Ghost"
                startMocking(lat, lng, alt, name)
            }
            ACTION_STOP_MOCK -> {
                stopMocking()
                stopSelf()
            }
            ACTION_SET_LOCATION -> {
                val lat = intent.getDoubleExtra(EXTRA_LAT, currentLat)
                val lng = intent.getDoubleExtra(EXTRA_LNG, currentLng)
                val alt = intent.getDoubleExtra(EXTRA_ALT, currentAlt)
                updateLocation(lat, lng, alt)
            }
            ACTION_START_ROUTE -> {
                val json = intent.getStringExtra(EXTRA_ROUTE_JSON) ?: return START_STICKY
                val speedMs = intent.getLongExtra(EXTRA_SPEED_MS, 1000L)
                startRouteSimulation(json, speedMs)
            }
            ACTION_STOP_ROUTE -> {
                routeJob?.cancel()
            }
        }
        return START_STICKY
    }

    // ─────────────────────────────────────────
    //  핵심: Mock Location 시작
    // ─────────────────────────────────────────
    private fun startMocking(lat: Double, lng: Double, alt: Double, name: String) {
        currentLat = lat
        currentLng = lng
        currentAlt = alt
        isActive = true

        // 포그라운드 알림 시작
        startForeground(NOTIFICATION_ID, buildNotification("📡 위치 변조 활성 — $name"))

        // 각 Provider에 Mock 등록
        providers.forEach { provider ->
            try {
                locationManager.addTestProvider(
                    provider,
                    false, false, false, false, true, true, true,
                    Criteria.POWER_LOW, Criteria.ACCURACY_FINE
                )
                locationManager.setTestProviderEnabled(provider, true)
            } catch (e: Exception) {
                Log.w(TAG, "Provider 등록 실패: $provider — ${e.message}")
            }
        }

        // 1초마다 위치 주입
        mockJob?.cancel()
        mockJob = serviceScope.launch {
            while (isActive) {
                injectLocation(currentLat, currentLng, currentAlt)
                delay(800L)
            }
        }

        broadcastStatus()
        Log.i(TAG, "▶ Mock 시작: $lat, $lng")
    }

    // ─────────────────────────────────────────
    //  위치 주입 (실제 GPS 변조 로직)
    // ─────────────────────────────────────────
    private fun injectLocation(lat: Double, lng: Double, alt: Double) {
        val now = SystemClock.elapsedRealtimeNanos()
        providers.forEach { provider ->
            try {
                val loc = Location(provider).apply {
                    latitude = lat
                    longitude = lng
                    altitude = alt
                    accuracy = 1.0f
                    time = System.currentTimeMillis()
                    elapsedRealtimeNanos = now
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        verticalAccuracyMeters = 1.0f
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        // 더 신뢰성 높은 위치로 표시
                    }
                }
                locationManager.setTestProviderLocation(provider, loc)
            } catch (e: Exception) {
                Log.w(TAG, "위치 주입 실패: $provider — ${e.message}")
            }
        }
    }

    // ─────────────────────────────────────────
    //  위치 즉시 업데이트
    // ─────────────────────────────────────────
    private fun updateLocation(lat: Double, lng: Double, alt: Double) {
        currentLat = lat
        currentLng = lng
        currentAlt = alt
        injectLocation(lat, lng, alt)
        broadcastStatus()
    }

    // ─────────────────────────────────────────
    //  경로 시뮬레이션
    // ─────────────────────────────────────────
    private fun startRouteSimulation(json: String, speedMs: Long) {
        val points = try {
            com.google.gson.Gson().fromJson(
                json,
                Array<com.ghostlocation.data.RoutePoint>::class.java
            ).toList()
        } catch (e: Exception) {
            Log.e(TAG, "경로 파싱 실패: ${e.message}")
            return
        }

        routeJob?.cancel()
        routeJob = serviceScope.launch {
            points.forEach { point ->
                updateLocation(point.latitude, point.longitude, currentAlt)
                updateNotification("🛤 경로 이동 중 — (${String.format("%.4f", point.latitude)}, ${String.format("%.4f", point.longitude)})")
                delay(speedMs)
            }
            updateNotification("✅ 경로 완료")
        }
    }

    // ─────────────────────────────────────────
    //  Mock 중지
    // ─────────────────────────────────────────
    private fun stopMocking() {
        isActive = false
        mockJob?.cancel()
        routeJob?.cancel()

        providers.forEach { provider ->
            try {
                locationManager.setTestProviderEnabled(provider, false)
                locationManager.removeTestProvider(provider)
            } catch (e: Exception) {
                Log.w(TAG, "Provider 제거 실패: $provider")
            }
        }

        broadcastStatus()
        stopForeground(STOP_FOREGROUND_REMOVE)
        Log.i(TAG, "■ Mock 중지")
    }

    // ─────────────────────────────────────────
    //  브로드캐스트
    // ─────────────────────────────────────────
    private fun broadcastStatus() {
        val intent = Intent(BROADCAST_STATUS).apply {
            putExtra(EXTRA_IS_ACTIVE, isActive)
            putExtra(EXTRA_CURRENT_LAT, currentLat)
            putExtra(EXTRA_CURRENT_LNG, currentLng)
        }
        sendBroadcast(intent)
    }

    // ─────────────────────────────────────────
    //  알림 채널 & 빌더
    // ─────────────────────────────────────────
    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "엔젤아름 Fake GPS",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "위치 변조 서비스 실행 중"
            setShowBadge(false)
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("👻 엔젤아름 Fake GPS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopMocking()
        serviceScope.cancel()
        super.onDestroy()
    }
}
