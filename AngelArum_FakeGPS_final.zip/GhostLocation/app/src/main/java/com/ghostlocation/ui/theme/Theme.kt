package com.ghostlocation.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ─────────────────────────────────────────────
//  사이버펑크 컬러 팔레트
// ─────────────────────────────────────────────
object GhostColors {
    // 배경
    val BgDeep       = Color(0xFF020408)   // 거의 검정
    val BgSurface    = Color(0xFF0A0D14)   // 카드 배경
    val BgElevated   = Color(0xFF0F1520)   // 올라간 레이어

    // 주요 강조색: 네온 사이안
    val Cyan         = Color(0xFF00F5FF)
    val CyanDim      = Color(0xFF00B8C8)
    val CyanGlow     = Color(0x3300F5FF)

    // 보조 강조색: 마젠타
    val Magenta      = Color(0xFFFF006E)
    val MagentaDim   = Color(0xFFCC0057)
    val MagentaGlow  = Color(0x33FF006E)

    // 경고/활성: 네온 그린
    val NeonGreen    = Color(0xFF00FF87)
    val NeonGreenDim = Color(0xFF00CC6A)

    // 경고: 앰버
    val Amber        = Color(0xFFFFB800)

    // 텍스트
    val TextPrimary  = Color(0xFFE0F4FF)
    val TextSecond   = Color(0xFF7A9BB5)
    val TextMuted    = Color(0xFF3A5570)

    // 구분선
    val Divider      = Color(0xFF1A2A3A)
    val Border       = Color(0xFF1E3044)
}

// ─────────────────────────────────────────────
//  Material3 ColorScheme 매핑
// ─────────────────────────────────────────────
private val GhostColorScheme = darkColorScheme(
    primary          = GhostColors.Cyan,
    onPrimary        = GhostColors.BgDeep,
    primaryContainer = GhostColors.CyanGlow,
    secondary        = GhostColors.Magenta,
    onSecondary      = Color.White,
    background       = GhostColors.BgDeep,
    surface          = GhostColors.BgSurface,
    onSurface        = GhostColors.TextPrimary,
    onBackground     = GhostColors.TextPrimary,
    outline          = GhostColors.Border,
    error            = GhostColors.Magenta
)

// ─────────────────────────────────────────────
//  폰트 패밀리 (기본 시스템 폰트 사용, 커스텀 ttf 추가 가능)
// ─────────────────────────────────────────────
val GhostTypography = Typography(
    headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        letterSpacing = 2.sp,
        color = GhostColors.Cyan
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        letterSpacing = 1.sp,
        color = GhostColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        letterSpacing = 0.8.sp,
        color = GhostColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        color = GhostColors.TextSecond
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        letterSpacing = 1.2.sp,
        color = GhostColors.TextMuted
    )
)

// ─────────────────────────────────────────────
//  테마 진입점
// ─────────────────────────────────────────────
@Composable
fun GhostLocationTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GhostColorScheme,
        typography = GhostTypography,
        content = content
    )
}
