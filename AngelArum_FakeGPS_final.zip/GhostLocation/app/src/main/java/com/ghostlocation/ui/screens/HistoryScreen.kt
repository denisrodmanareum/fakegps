package com.ghostlocation.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.ghostlocation.data.HistoryEntry
import com.ghostlocation.ui.MainUiState
import com.ghostlocation.ui.MainViewModel
import com.ghostlocation.ui.components.*
import com.ghostlocation.ui.theme.GhostColors
import com.ghostlocation.utils.LocationHelper

@Composable
fun HistoryScreen(uiState: MainUiState, viewModel: MainViewModel) {
    Column(
        modifier = Modifier.fillMaxSize().background(GhostColors.BgDeep).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            ScanlineHeader(title = "이동 히스토리", subtitle = "최근 변조 위치 ${uiState.history.size}개")
            if (uiState.history.isNotEmpty()) {
                IconButton(onClick = { viewModel.clearHistory() }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "전체 삭제", tint = GhostColors.Magenta, modifier = Modifier.size(20.dp))
                }
            }
        }

        if (uiState.history.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("🕓", fontSize = 48.sp)
                    Text("아직 이동 기록이 없습니다", color = GhostColors.TextMuted, fontSize = 14.sp)
                    Text("위치 변조를 시작하면 자동으로 기록됩니다", color = GhostColors.TextMuted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(uiState.history, key = { it.id }) { entry ->
                    HistoryItem(
                        entry = entry,
                        onSelect = { viewModel.selectHistory(entry) },
                        onSaveToFavorites = {
                            viewModel.addToFavorites(
                                com.ghostlocation.data.GhostLocation(name = entry.name, latitude = entry.latitude, longitude = entry.longitude)
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryItem(
    entry: HistoryEntry,
    onSelect: () -> Unit,
    onSaveToFavorites: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(GhostColors.BgSurface, RoundedCornerShape(10.dp))
            .border(1.dp, GhostColors.Border, RoundedCornerShape(10.dp))
            .clickable { onSelect() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            // 타임라인 도트
            Box(
                modifier = Modifier.size(36.dp)
                    .background(GhostColors.Cyan.copy(0.1f), RoundedCornerShape(8.dp))
                    .border(1.dp, GhostColors.Cyan.copy(0.3f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.History, contentDescription = null, tint = GhostColors.Cyan, modifier = Modifier.size(18.dp))
            }
            Column {
                Text(entry.name, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = GhostColors.TextPrimary, maxLines = 1)
                Spacer(Modifier.height(2.dp))
                Text(
                    "${String.format("%.4f", entry.latitude)}, ${String.format("%.4f", entry.longitude)}",
                    fontSize = 11.sp, color = GhostColors.TextMuted
                )
                Text(LocationHelper.formatTimestamp(entry.timestamp), fontSize = 10.sp, color = GhostColors.TextMuted, letterSpacing = 0.3.sp)
            }
        }
        // 버튼들
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            IconButton(onClick = onSaveToFavorites, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Default.StarBorder, contentDescription = "즐겨찾기 저장", tint = GhostColors.Amber, modifier = Modifier.size(16.dp))
            }
            IconButton(onClick = onSelect, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Default.PlayArrow, contentDescription = "이 위치로 이동", tint = GhostColors.NeonGreen, modifier = Modifier.size(16.dp))
            }
        }
    }
}
