package com.ghostlocation.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.ghostlocation.data.MovementSpeed
import com.ghostlocation.ui.MainUiState
import com.ghostlocation.ui.MainViewModel
import com.ghostlocation.ui.components.*
import com.ghostlocation.ui.theme.GhostColors

@Composable
fun RouteScreen(
    uiState: MainUiState,
    viewModel: MainViewModel
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var addLat by remember { mutableStateOf("") }
    var addLng by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GhostColors.BgDeep)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ── 헤더 ────────────────────────────
        ScanlineHeader(
            title = "경로 시뮬레이션",
            subtitle = "A→B 이동 경로를 설정하고 자동으로 이동합니다"
        )

        // ── 속도 선택 ────────────────────────
        NeonCard(modifier = Modifier.fillMaxWidth(), glowColor = GhostColors.Magenta) {
            Text(
                text = "이동 속도",
                fontSize = 12.sp,
                color = GhostColors.TextMuted,
                letterSpacing = 1.sp
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MovementSpeed.entries.forEach { speed ->
                    val isSelected = uiState.selectedSpeed == speed
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.setSpeed(speed) }
                            .background(
                                if (isSelected) GhostColors.Magenta.copy(0.2f) else GhostColors.BgElevated,
                                RoundedCornerShape(6.dp)
                            )
                            .border(
                                1.dp,
                                if (isSelected) GhostColors.Magenta else GhostColors.Border,
                                RoundedCornerShape(6.dp)
                            )
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = when (speed) {
                                    MovementSpeed.WALK -> "🚶"
                                    MovementSpeed.BIKE -> "🚲"
                                    MovementSpeed.CAR  -> "🚗"
                                    MovementSpeed.FAST -> "✈️"
                                },
                                fontSize = 18.sp
                            )
                            Text(
                                text = speed.name,
                                fontSize = 9.sp,
                                color = if (isSelected) GhostColors.Magenta else GhostColors.TextMuted,
                                letterSpacing = 0.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // ── 경로 포인트 목록 ─────────────────
        NeonCard(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            glowColor = GhostColors.Cyan
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ScanlineHeader(
                    title = "경로 포인트",
                    subtitle = "${uiState.routePoints.size}개 등록됨"
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (uiState.routePoints.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.clearRoute() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "전체 삭제",
                                tint = GhostColors.Magenta,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    IconButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "포인트 추가",
                            tint = GhostColors.Cyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            if (uiState.routePoints.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "＋ 버튼으로 경로 포인트를 추가하세요",
                        color = GhostColors.TextMuted,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(uiState.routePoints) { index, point ->
                        RoutePointItem(
                            index = index,
                            lat = point.latitude,
                            lng = point.longitude,
                            isFirst = index == 0,
                            isLast = index == uiState.routePoints.lastIndex,
                            onDelete = { viewModel.removeRoutePoint(index) }
                        )
                    }
                }
            }
        }

        // ── 시작/중지 버튼 ───────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CyberButton(
                text = if (uiState.isRouteRunning) "⏹ 경로 중지" else "▶ 경로 시작",
                onClick = {
                    if (uiState.isRouteRunning) viewModel.stopRoute()
                    else viewModel.startRoute()
                },
                modifier = Modifier.weight(1f),
                color = if (uiState.isRouteRunning) GhostColors.Magenta else GhostColors.NeonGreen,
                enabled = uiState.routePoints.size >= 2 || uiState.isRouteRunning
            )
        }

        if (uiState.routePoints.size < 2 && !uiState.isRouteRunning) {
            Text(
                text = "⚠ 최소 2개의 포인트가 필요합니다",
                fontSize = 11.sp,
                color = GhostColors.Amber,
                letterSpacing = 0.5.sp
            )
        }
    }

    // ── 포인트 추가 다이얼로그 ──────────────
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = {
                showAddDialog = false
                addLat = ""; addLng = ""
            },
            containerColor = GhostColors.BgElevated,
            shape = RoundedCornerShape(12.dp),
            title = {
                Text(
                    "포인트 추가",
                    color = GhostColors.Cyan,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CyberTextField(
                        value = addLat,
                        onValueChange = { addLat = it },
                        label = "위도",
                        placeholder = "37.5665",
                        modifier = Modifier.fillMaxWidth()
                    )
                    CyberTextField(
                        value = addLng,
                        onValueChange = { addLng = it },
                        label = "경도",
                        placeholder = "126.9780",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                CyberButton(
                    text = "추가",
                    onClick = {
                        val lat = addLat.toDoubleOrNull()
                        val lng = addLng.toDoubleOrNull()
                        if (lat != null && lng != null) {
                            viewModel.addRoutePoint(lat, lng)
                            showAddDialog = false
                            addLat = ""; addLng = ""
                        } else {
                            viewModel.showSnackbar("올바른 좌표를 입력하세요")
                        }
                    },
                    color = GhostColors.Cyan
                )
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("취소", color = GhostColors.TextMuted)
                }
            }
        )
    }
}

@Composable
private fun RoutePointItem(
    index: Int,
    lat: Double,
    lng: Double,
    isFirst: Boolean,
    isLast: Boolean,
    onDelete: () -> Unit
) {
    val pointColor = when {
        isFirst -> GhostColors.NeonGreen
        isLast  -> GhostColors.Magenta
        else    -> GhostColors.Cyan
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(GhostColors.BgElevated, RoundedCornerShape(8.dp))
            .border(1.dp, pointColor.copy(0.3f), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 번호 배지
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(pointColor.copy(0.2f), RoundedCornerShape(12.dp))
                    .border(1.dp, pointColor.copy(0.6f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${index + 1}",
                    fontSize = 10.sp,
                    color = pointColor,
                    fontWeight = FontWeight.Bold
                )
            }
            Column {
                Text(
                    text = when {
                        isFirst -> "시작점"
                        isLast  -> "종료점"
                        else    -> "경유점 $index"
                    },
                    fontSize = 11.sp,
                    color = pointColor,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "${String.format("%.5f", lat)}, ${String.format("%.5f", lng)}",
                    fontSize = 11.sp,
                    color = GhostColors.TextMuted
                )
            }
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
            Icon(
                Icons.Default.Close,
                contentDescription = "삭제",
                tint = GhostColors.TextMuted,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
