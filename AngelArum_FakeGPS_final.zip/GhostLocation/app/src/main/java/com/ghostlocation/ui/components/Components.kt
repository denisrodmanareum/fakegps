package com.ghostlocation.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.ghostlocation.ui.theme.GhostColors

// ─────────────────────────────────────────────
//  네온 테두리 카드
// ─────────────────────────────────────────────
@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    glowColor: Color = GhostColors.Cyan,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = modifier
            .drawBehind {
                // 글로우 효과 (블러 없이 레이어 겹치기)
                for (i in 1..4) {
                    drawRoundRect(
                        color = glowColor.copy(alpha = 0.06f / i),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx()),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = (i * 3).dp.toPx())
                    )
                }
            }
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        glowColor.copy(alpha = 0.8f),
                        glowColor.copy(alpha = 0.2f),
                        glowColor.copy(alpha = 0.6f)
                    )
                ),
                shape = RoundedCornerShape(12.dp)
            )
            .clip(RoundedCornerShape(12.dp))
            .background(GhostColors.BgSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

// ─────────────────────────────────────────────
//  사이버펑크 버튼
// ─────────────────────────────────────────────
@Composable
fun CyberButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = GhostColors.Cyan,
    enabled: Boolean = true,
    icon: @Composable (() -> Unit)? = null
) {
    val animAlpha by animateFloatAsState(
        targetValue = if (enabled) 1f else 0.4f,
        label = "alpha"
    )

    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color.copy(alpha = 0.12f),
            contentColor = color,
            disabledContainerColor = color.copy(alpha = 0.05f),
            disabledContentColor = color.copy(alpha = 0.3f)
        ),
        border = BorderStroke(1.dp, color.copy(alpha = animAlpha)),
        shape = RoundedCornerShape(6.dp)
    ) {
        icon?.let {
            it()
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            fontSize = 13.sp
        )
    }
}

// ─────────────────────────────────────────────
//  펄싱 상태 인디케이터
// ─────────────────────────────────────────────
@Composable
fun PulsingDot(
    isActive: Boolean,
    activeColor: Color = GhostColors.NeonGreen,
    inactiveColor: Color = GhostColors.TextMuted
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val color = if (isActive) activeColor else inactiveColor
    val dotScale = if (isActive) scale else 1f

    Box(
        modifier = Modifier
            .size(12.dp)
            .drawBehind {
                if (isActive) {
                    drawCircle(
                        color = color.copy(alpha = 0.3f),
                        radius = size.minDimension / 2 * dotScale * 1.5f
                    )
                }
                drawCircle(
                    color = color,
                    radius = size.minDimension / 2 * (if (isActive) dotScale else 1f)
                )
            }
    )
}

// ─────────────────────────────────────────────
//  상태 배지
// ─────────────────────────────────────────────
@Composable
fun StatusBadge(isMocking: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .border(
                1.dp,
                if (isMocking) GhostColors.NeonGreen.copy(0.5f) else GhostColors.Border,
                RoundedCornerShape(20.dp)
            )
            .background(
                if (isMocking) GhostColors.NeonGreen.copy(0.08f) else GhostColors.BgElevated,
                RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        PulsingDot(isActive = isMocking)
        Text(
            text = if (isMocking) "ACTIVE" else "INACTIVE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = if (isMocking) GhostColors.NeonGreen else GhostColors.TextMuted
        )
    }
}

// ─────────────────────────────────────────────
//  섹션 헤더 (스캔라인 효과)
// ─────────────────────────────────────────────
@Composable
fun ScanlineHeader(title: String, subtitle: String? = null) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(20.dp)
                    .background(GhostColors.Cyan, RoundedCornerShape(2.dp))
            )
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = GhostColors.TextPrimary
            )
            Spacer(Modifier.weight(1f))
            // 데코 라인
            Box(
                modifier = Modifier
                    .height(1.dp)
                    .width(40.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(GhostColors.Cyan.copy(0.6f), Color.Transparent)
                        )
                    )
            )
        }
        subtitle?.let {
            Text(
                text = it,
                fontSize = 11.sp,
                color = GhostColors.TextMuted,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(start = 15.dp, top = 2.dp)
            )
        }
    }
}

// ─────────────────────────────────────────────
//  입력 필드 (사이버펑크 스타일)
// ─────────────────────────────────────────────
@Composable
fun CyberTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.sp) },
        placeholder = { Text(placeholder, color = GhostColors.TextMuted, fontSize = 12.sp) },
        modifier = modifier,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GhostColors.Cyan,
            unfocusedBorderColor = GhostColors.Border,
            focusedLabelColor = GhostColors.Cyan,
            unfocusedLabelColor = GhostColors.TextMuted,
            cursorColor = GhostColors.Cyan,
            focusedTextColor = GhostColors.TextPrimary,
            unfocusedTextColor = GhostColors.TextPrimary,
            focusedContainerColor = GhostColors.BgElevated,
            unfocusedContainerColor = GhostColors.BgSurface
        ),
        shape = RoundedCornerShape(8.dp),
        singleLine = true
    )
}

// ─────────────────────────────────────────────
//  좌표 표시 칩
// ─────────────────────────────────────────────
@Composable
fun CoordChip(lat: Double, lng: Double) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(GhostColors.BgElevated, RoundedCornerShape(4.dp))
            .border(1.dp, GhostColors.Border, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            Icons.Default.LocationOn,
            contentDescription = null,
            tint = GhostColors.Cyan,
            modifier = Modifier.size(12.dp)
        )
        Text(
            text = "${String.format("%.5f", lat)}, ${String.format("%.5f", lng)}",
            fontSize = 11.sp,
            color = GhostColors.Cyan,
            letterSpacing = 0.5.sp
        )
    }
}
