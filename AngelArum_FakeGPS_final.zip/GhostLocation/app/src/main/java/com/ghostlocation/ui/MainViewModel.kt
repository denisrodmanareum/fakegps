package com.ghostlocation.ui

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ghostlocation.data.*
import com.ghostlocation.service.MockLocationService
import com.ghostlocation.utils.LocationHelper
import com.google.gson.Gson
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class MainUiState(
    val isMocking: Boolean = false,
    val currentLocation: GhostLocation? = null,
    val selectedTab: AppTab = AppTab.MAP,
    val routePoints: List<RoutePoint> = emptyList(),
    val isRouteRunning: Boolean = false,
    val selectedSpeed: MovementSpeed = MovementSpeed.WALK,
    val favorites: List<GhostLocation> = emptyList(),
    val history: List<HistoryEntry> = emptyList(),
    val showCoordDialog: Boolean = false,
    val coordInputLat: String = "",
    val coordInputLng: String = "",
    val coordInputName: String = "",
    val searchQuery: String = "",
    val searchResults: List<GhostLocation> = emptyList(),
    val isSearching: Boolean = false,
    val selectedTimer: AutoStopTimer = AutoStopTimer.OFF,
    val timerRemainingSeconds: Int = 0,
    val randomWalkRadius: Float = 300f,
    val randomWalkSteps: Int = 8,
    val realLocation: GhostLocation? = null,
    val snackbarMessage: String? = null
)

enum class AppTab { MAP, ROUTE, FAVORITES, HISTORY }

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = PreferencesRepository(application)
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var searchJob: Job? = null

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val isActive = intent.getBooleanExtra(MockLocationService.EXTRA_IS_ACTIVE, false)
            _uiState.update { it.copy(isMocking = isActive) }
        }
    }

    init {
        viewModelScope.launch { repo.favoritesFlow.collect { favs -> _uiState.update { it.copy(favorites = favs) } } }
        viewModelScope.launch { repo.historyFlow.collect { hist -> _uiState.update { it.copy(history = hist) } } }
        val filter = IntentFilter(MockLocationService.BROADCAST_STATUS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            application.registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            application.registerReceiver(statusReceiver, filter)
        }
        loadRealLocation()
    }

    fun selectTab(tab: AppTab) = _uiState.update { it.copy(selectedTab = tab) }

    fun loadRealLocation() {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val loc = LocationHelper.getRealLocation(ctx)
            _uiState.update { it.copy(realLocation = loc) }
        }
    }

    fun goToRealLocation() {
        viewModelScope.launch {
            loadRealLocation()
            delay(300)
            val real = _uiState.value.realLocation
            if (real == null) { showSnackbar("실제 위치를 가져올 수 없습니다. 위치 권한을 확인하세요."); return@launch }
            if (_uiState.value.isMocking) {
                stopMocking()
                showSnackbar("✅ 실제 위치로 복귀 완료")
            } else {
                showSnackbar("📍 현재 실제 위치: ${String.format("%.4f", real.latitude)}, ${String.format("%.4f", real.longitude)}")
            }
            _uiState.update { it.copy(currentLocation = real) }
        }
    }

    fun onMapLocationSelected(lat: Double, lng: Double) {
        _uiState.update { it.copy(currentLocation = GhostLocation(name = "선택된 위치", latitude = lat, longitude = lng)) }
    }

    fun startMocking() {
        val loc = _uiState.value.currentLocation ?: run { showSnackbar("먼저 위치를 선택하세요"); return }
        MockLocationService.startMock(getApplication(), loc)
        _uiState.update { it.copy(isMocking = true) }
        viewModelScope.launch {
            repo.saveLastLocation(loc)
            repo.addHistory(HistoryEntry(name = loc.name, latitude = loc.latitude, longitude = loc.longitude))
        }
        val timer = _uiState.value.selectedTimer
        if (timer != AutoStopTimer.OFF) startAutoStopTimer(timer.minutes * 60)
        showSnackbar("📡 위치 변조 시작: ${loc.name}")
    }

    fun stopMocking() {
        MockLocationService.stopMock(getApplication())
        timerJob?.cancel()
        _uiState.update { it.copy(isMocking = false, timerRemainingSeconds = 0) }
        showSnackbar("■ 위치 변조 중지")
    }

    private fun startAutoStopTimer(seconds: Int) {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var remaining = seconds
            while (remaining > 0) {
                _uiState.update { it.copy(timerRemainingSeconds = remaining) }
                delay(1000)
                remaining--
            }
            stopMocking()
            showSnackbar("⏰ 타이머 만료 — 위치 변조 자동 중지")
        }
    }

    fun setAutoStopTimer(timer: AutoStopTimer) = _uiState.update { it.copy(selectedTimer = timer) }

    fun showCoordDialog() = _uiState.update { it.copy(showCoordDialog = true) }
    fun dismissCoordDialog() = _uiState.update { it.copy(showCoordDialog = false, coordInputLat = "", coordInputLng = "", coordInputName = "") }
    fun updateCoordLat(v: String) = _uiState.update { it.copy(coordInputLat = v) }
    fun updateCoordLng(v: String) = _uiState.update { it.copy(coordInputLng = v) }
    fun updateCoordName(v: String) = _uiState.update { it.copy(coordInputName = v) }

    fun confirmCoordInput() {
        val s = _uiState.value
        val lat = s.coordInputLat.toDoubleOrNull() ?: run { showSnackbar("위도가 올바르지 않습니다"); return }
        val lng = s.coordInputLng.toDoubleOrNull() ?: run { showSnackbar("경도가 올바르지 않습니다"); return }
        if (lat !in -90.0..90.0) { showSnackbar("위도: -90 ~ 90 범위"); return }
        if (lng !in -180.0..180.0) { showSnackbar("경도: -180 ~ 180 범위"); return }
        val loc = GhostLocation(name = s.coordInputName.ifBlank { "좌표 입력 위치" }, latitude = lat, longitude = lng)
        _uiState.update { it.copy(currentLocation = loc, showCoordDialog = false) }
        showSnackbar("📍 위치 설정: ${loc.name}")
    }

    fun updateSearchQuery(q: String) {
        _uiState.update { it.copy(searchQuery = q) }
        searchJob?.cancel()
        if (q.length >= 2) {
            searchJob = viewModelScope.launch {
                delay(600)
                _uiState.update { it.copy(isSearching = true) }
                val results = LocationHelper.searchAddress(getApplication(), q)
                _uiState.update { it.copy(searchResults = results, isSearching = false) }
                if (results.isEmpty()) showSnackbar("검색 결과가 없습니다")
            }
        } else {
            _uiState.update { it.copy(searchResults = emptyList()) }
        }
    }

    fun selectSearchResult(loc: GhostLocation) {
        _uiState.update { it.copy(currentLocation = loc, searchQuery = "", searchResults = emptyList()) }
        showSnackbar("📍 ${loc.name}")
    }

    fun clearSearch() = _uiState.update { it.copy(searchQuery = "", searchResults = emptyList()) }

    fun setRandomLocation() {
        val loc = LocationHelper.randomLocation()
        _uiState.update { it.copy(currentLocation = loc) }
        showSnackbar("🎲 랜덤 위치 생성됨")
    }

    fun startRandomWalk() {
        val s = _uiState.value
        val center = s.currentLocation ?: run { showSnackbar("기준 위치를 먼저 선택하세요"); return }
        val points = LocationHelper.generateRandomWalk(center.latitude, center.longitude, s.randomWalkRadius.toDouble(), s.randomWalkSteps)
        _uiState.update { it.copy(routePoints = points.map { (lat, lng) -> RoutePoint(lat, lng) }, selectedTab = AppTab.ROUTE) }
        showSnackbar("🚶 랜덤 워킹 경로 생성됨 (${points.size}개 포인트)")
    }

    fun setRandomWalkRadius(r: Float) = _uiState.update { it.copy(randomWalkRadius = r) }
    fun setRandomWalkSteps(s: Int) = _uiState.update { it.copy(randomWalkSteps = s) }

    fun addToFavorites(location: GhostLocation? = null) {
        val loc = location ?: _uiState.value.currentLocation ?: run { showSnackbar("저장할 위치를 먼저 선택하세요"); return }
        viewModelScope.launch { repo.saveFavorite(loc); showSnackbar("⭐ 즐겨찾기 저장: ${loc.name}") }
    }

    fun deleteFavorite(id: String) {
        viewModelScope.launch { repo.deleteFavorite(id); showSnackbar("즐겨찾기 삭제됨") }
    }

    fun selectFavorite(loc: GhostLocation) {
        _uiState.update { it.copy(currentLocation = loc, selectedTab = AppTab.MAP) }
        showSnackbar("📍 ${loc.name} 선택됨")
    }

    fun selectHistory(entry: HistoryEntry) {
        val loc = GhostLocation(name = entry.name, latitude = entry.latitude, longitude = entry.longitude)
        _uiState.update { it.copy(currentLocation = loc, selectedTab = AppTab.MAP) }
        showSnackbar("📍 ${entry.name}")
    }

    fun clearHistory() { viewModelScope.launch { repo.clearHistory(); showSnackbar("히스토리 삭제됨") } }

    fun addRoutePoint(lat: Double, lng: Double) = _uiState.update { it.copy(routePoints = it.routePoints + RoutePoint(lat, lng)) }
    fun removeRoutePoint(i: Int) = _uiState.update { s -> s.copy(routePoints = s.routePoints.toMutableList().also { it.removeAt(i) }) }
    fun clearRoute() = _uiState.update { it.copy(routePoints = emptyList(), isRouteRunning = false) }
    fun setSpeed(speed: MovementSpeed) = _uiState.update { it.copy(selectedSpeed = speed) }

    fun startRoute() {
        val s = _uiState.value
        if (s.routePoints.size < 2) { showSnackbar("경로 포인트를 2개 이상 추가하세요"); return }
        val ctx = getApplication<Application>()
        if (!s.isMocking) {
            val first = s.routePoints.first()
            MockLocationService.startMock(ctx, GhostLocation(name = "경로 시작점", latitude = first.latitude, longitude = first.longitude))
        }
        ctx.startService(Intent(ctx, MockLocationService::class.java).apply {
            action = MockLocationService.ACTION_START_ROUTE
            putExtra(MockLocationService.EXTRA_ROUTE_JSON, Gson().toJson(s.routePoints))
            putExtra(MockLocationService.EXTRA_SPEED_MS, s.selectedSpeed.intervalMs)
        })
        _uiState.update { it.copy(isRouteRunning = true, isMocking = true) }
        showSnackbar("🛤 경로 시뮬레이션 시작 (${s.selectedSpeed.label})")
    }

    fun stopRoute() {
        getApplication<Application>().startService(Intent(getApplication(), MockLocationService::class.java).apply {
            action = MockLocationService.ACTION_STOP_ROUTE
        })
        _uiState.update { it.copy(isRouteRunning = false) }
    }

    fun showSnackbar(msg: String) = _uiState.update { it.copy(snackbarMessage = msg) }
    fun clearSnackbar() = _uiState.update { it.copy(snackbarMessage = null) }

    override fun onCleared() {
        super.onCleared()
        try { getApplication<Application>().unregisterReceiver(statusReceiver) } catch (_: Exception) {}
    }
}
