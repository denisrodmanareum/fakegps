package com.ghostlocation.ui.screens

import android.view.ViewGroup
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import com.ghostlocation.data.AutoStopTimer
import com.ghostlocation.data.GhostLocation
import com.ghostlocation.ui.MainUiState
import com.ghostlocation.ui.MainViewModel
import com.ghostlocation.ui.components.*
import com.ghostlocation.ui.theme.GhostColors
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView

@Composable
fun MapScreen(uiState: MainUiState, viewModel: MainViewModel) {
    var mapLibreMap by remember { mutableStateOf<MapLibreMap?>(null) }
    var showSearchBar by remember { mutableStateOf(false) }
    var showTimerPanel by remember { mutableStateOf(false) }
    var showRandomWalkPanel by remember { mutableStateOf(false) }

    // 위치 변경 시 지도 카메라 이동
    LaunchedEffect(uiState.currentLocation) {
        uiState.currentLocation?.let { loc ->
            mapLibreMap?.animateCamera(
                org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(
                    LatLng(loc.latitude, loc.longitude), 14.0
                )
            )
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(GhostColors.BgDeep)) {

        // ── 검색바 (토글) ────────────────────
        AnimatedVisibility(visible = showSearchBar) {
            SearchBar(uiState = uiState, viewModel = viewModel, onClose = { showSearchBar = false })
        }

        // ── 선택된 위치 카드 ──────────────────
        uiState.currentLocation?.let { loc ->
            NeonCard(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                glowColor = if (uiState.isMocking) GhostColors.NeonGreen else GhostColors.Cyan
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(loc.name, fontWeight = FontWeight.Bold, color = GhostColors.TextPrimary, fontSize = 13.sp, maxLines = 1)
                        Spacer(Modifier.height(4.dp))
                        CoordChip(loc.latitude, loc.longitude)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        // 즐겨찾기
                        IconButton(onClick = { viewModel.addToFavorites() }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Default.Star, contentDescription = "즐겨찾기", tint = GhostColors.Amber, modifier = Modifier.size(18.dp))
                        }
                        // 랜덤 워킹
                        IconButton(onClick = { showRandomWalkPanel = !showRandomWalkPanel }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Default.DirectionsWalk, contentDescription = "랜덤 워킹", tint = GhostColors.Magenta, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        // ── 랜덤 워크 패널 ─────────────────
        AnimatedVisibility(visible = showRandomWalkPanel && uiState.currentLocation != null) {
            RandomWalkPanel(uiState = uiState, viewModel = viewModel, onClose = { showRandomWalkPanel = false })
        }

        // ── 타이머 패널 ──────────────────────
        AnimatedVisibility(visible = showTimerPanel) {
            TimerPanel(uiState = uiState, viewModel = viewModel, onClose = { showTimerPanel = false })
        }

        // ── 지도 ────────────────────────────
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            AndroidView(
                factory = { ctx ->
                    MapLibre.getInstance(ctx)
                    MapView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                        getMapAsync { map ->
                            mapLibreMap = map
                            map.setStyle("https://demotiles.maplibre.org/style.json") {
                                map.cameraPosition = CameraPosition.Builder().target(LatLng(37.5665, 126.9780)).zoom(12.0).build()
                            }
                            map.addOnMapClickListener { latLng ->
                                viewModel.onMapLocationSelected(latLng.latitude, latLng.longitude)
                                true
                            }
                        }
                        onStart()
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // 힌트
            if (uiState.currentLocation == null) {
                Box(modifier = Modifier.align(Alignment.Center).background(GhostColors.BgDeep.copy(0.88f), RoundedCornerShape(8.dp)).border(1.dp, GhostColors.Border, RoundedCornerShape(8.dp)).padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text("지도를 탭하여 위치 선택", color = GhostColors.TextSecond, fontSize = 13.sp)
                }
            }

            // 우상단 액션 버튼들
            Column(modifier = Modifier.align(Alignment.TopEnd).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // 검색
                MapFab(icon = Icons.Default.Search, color = GhostColors.Cyan, onClick = { showSearchBar = !showSearchBar })
                // 좌표 입력
                MapFab(icon = Icons.Default.Edit, color = GhostColors.Cyan, onClick = { viewModel.showCoordDialog() })
                // 랜덤 위치
                MapFab(icon = Icons.Default.Casino, color = GhostColors.Magenta, onClick = { viewModel.setRandomLocation() })
                // 내 실제 위치
                MapFab(icon = Icons.Default.MyLocation, color = GhostColors.NeonGreen, onClick = { viewModel.goToRealLocation() })
            }

            // 타이머 잔여 표시 (좌상단)
            if (uiState.isMocking && uiState.timerRemainingSeconds > 0) {
                Box(modifier = Modifier.align(Alignment.TopStart).padding(10.dp).background(GhostColors.BgElevated.copy(0.95f), RoundedCornerShape(8.dp)).border(1.dp, GhostColors.Amber.copy(0.6f), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = GhostColors.Amber, modifier = Modifier.size(14.dp))
                        Text(formatTimer(uiState.timerRemainingSeconds), fontSize = 12.sp, color = GhostColors.Amber, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ── 컨트롤 패널 ──────────────────────
        Column(modifier = Modifier.fillMaxWidth().background(GhostColors.BgSurface).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                CyberButton(
                    text = if (uiState.isMocking) "■  변조 중지" else "▶  변조 시작",
                    onClick = { if (uiState.isMocking) viewModel.stopMocking() else viewModel.startMocking() },
                    modifier = Modifier.weight(1f),
                    color = if (uiState.isMocking) GhostColors.Magenta else GhostColors.NeonGreen,
                    enabled = uiState.isMocking || uiState.currentLocation != null
                )
                // 내 위치로 복귀 버튼
                CyberButton(
                    text = "📍 내 위치",
                    onClick = { viewModel.goToRealLocation() },
                    color = GhostColors.Cyan
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                StatusBadge(isMocking = uiState.isMocking)
                // 타이머 설정 버튼
                TextButton(onClick = { showTimerPanel = !showTimerPanel }) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = GhostColors.TextMuted, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (uiState.selectedTimer == AutoStopTimer.OFF) "자동 중지: OFF" else "자동 중지: ${uiState.selectedTimer.label}",
                        fontSize = 11.sp, color = GhostColors.TextMuted, letterSpacing = 0.3.sp
                    )
                }
            }
        }
    }

    if (uiState.showCoordDialog) CoordInputDialog(uiState = uiState, viewModel = viewModel)
}

@Composable
private fun MapFab(icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    FloatingActionButton(
        onClick = onClick,
        modifier = Modifier.size(42.dp),
        containerColor = GhostColors.BgElevated,
        contentColor = color
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun SearchBar(uiState: MainUiState, viewModel: MainViewModel, onClose: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().background(GhostColors.BgSurface).padding(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            CyberTextField(
                value = uiState.searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                label = "장소 또는 주소 검색",
                placeholder = "예: 에펠탑, 서울역, Times Square",
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { viewModel.clearSearch(); onClose() }) {
                Icon(Icons.Default.Close, contentDescription = "닫기", tint = GhostColors.TextMuted)
            }
        }
        if (uiState.isSearching) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), color = GhostColors.Cyan, trackColor = GhostColors.BgElevated)
        }
        if (uiState.searchResults.isNotEmpty()) {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(uiState.searchResults) { loc ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { viewModel.selectSearchResult(loc); onClose() }
                            .background(GhostColors.BgElevated, RoundedCornerShape(6.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = GhostColors.Cyan, modifier = Modifier.size(16.dp))
                        Column {
                            Text(loc.name, fontSize = 12.sp, color = GhostColors.TextPrimary, maxLines = 1)
                            Text("${String.format("%.4f", loc.latitude)}, ${String.format("%.4f", loc.longitude)}", fontSize = 10.sp, color = GhostColors.TextMuted)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimerPanel(uiState: MainUiState, viewModel: MainViewModel, onClose: () -> Unit) {
    NeonCard(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), glowColor = GhostColors.Amber) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("⏰ 자동 중지 타이머", fontSize = 12.sp, color = GhostColors.Amber, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, contentDescription = null, tint = GhostColors.TextMuted, modifier = Modifier.size(14.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AutoStopTimer.entries.forEach { timer ->
                val selected = uiState.selectedTimer == timer
                Box(
                    modifier = Modifier.weight(1f).clickable { viewModel.setAutoStopTimer(timer) }
                        .background(if (selected) GhostColors.Amber.copy(0.2f) else GhostColors.BgElevated, RoundedCornerShape(6.dp))
                        .border(1.dp, if (selected) GhostColors.Amber else GhostColors.Border, RoundedCornerShape(6.dp))
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(timer.label, fontSize = 11.sp, color = if (selected) GhostColors.Amber else GhostColors.TextMuted, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun RandomWalkPanel(uiState: MainUiState, viewModel: MainViewModel, onClose: () -> Unit) {
    NeonCard(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), glowColor = GhostColors.Magenta) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("🚶 랜덤 워킹 설정", fontSize = 12.sp, color = GhostColors.Magenta, fontWeight = FontWeight.Bold)
            IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, contentDescription = null, tint = GhostColors.TextMuted, modifier = Modifier.size(14.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("반경: ${uiState.randomWalkRadius.toInt()}m", fontSize = 11.sp, color = GhostColors.TextSecond)
        Slider(value = uiState.randomWalkRadius, onValueChange = { viewModel.setRandomWalkRadius(it) }, valueRange = 100f..2000f,
            colors = SliderDefaults.colors(thumbColor = GhostColors.Magenta, activeTrackColor = GhostColors.Magenta, inactiveTrackColor = GhostColors.Border))
        Text("포인트 수: ${uiState.randomWalkSteps}개", fontSize = 11.sp, color = GhostColors.TextSecond)
        Slider(value = uiState.randomWalkSteps.toFloat(), onValueChange = { viewModel.setRandomWalkSteps(it.toInt()) }, valueRange = 4f..20f, steps = 15,
            colors = SliderDefaults.colors(thumbColor = GhostColors.Magenta, activeTrackColor = GhostColors.Magenta, inactiveTrackColor = GhostColors.Border))
        Spacer(Modifier.height(4.dp))
        CyberButton(text = "🛤 경로 생성 → 경로 탭으로 이동", onClick = { viewModel.startRandomWalk(); onClose() }, modifier = Modifier.fillMaxWidth(), color = GhostColors.Magenta)
    }
}

@Composable
private fun CoordInputDialog(uiState: MainUiState, viewModel: MainViewModel) {
    AlertDialog(
        onDismissRequest = { viewModel.dismissCoordDialog() },
        containerColor = GhostColors.BgElevated,
        shape = RoundedCornerShape(12.dp),
        title = { Text("좌표 직접 입력", color = GhostColors.Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CyberTextField(value = uiState.coordInputName, onValueChange = { viewModel.updateCoordName(it) }, label = "위치 이름", placeholder = "예: 에펠탑", modifier = Modifier.fillMaxWidth())
                CyberTextField(value = uiState.coordInputLat, onValueChange = { viewModel.updateCoordLat(it) }, label = "위도 (Latitude)", placeholder = "예: 48.8584", modifier = Modifier.fillMaxWidth())
                CyberTextField(value = uiState.coordInputLng, onValueChange = { viewModel.updateCoordLng(it) }, label = "경도 (Longitude)", placeholder = "예: 2.2945", modifier = Modifier.fillMaxWidth())
                Text("⚡ 빠른 선택", fontSize = 11.sp, color = GhostColors.TextMuted, letterSpacing = 1.sp)
                QuickCityGrid(viewModel = viewModel)
            }
        },
        confirmButton = { CyberButton(text = "적용", onClick = { viewModel.confirmCoordInput() }, color = GhostColors.Cyan) },
        dismissButton = { TextButton(onClick = { viewModel.dismissCoordDialog() }) { Text("취소", color = GhostColors.TextMuted) } }
    )
}

@Composable
private fun QuickCityGrid(viewModel: MainViewModel) {
    val cities = listOf(
        Triple("서울", 37.5665, 126.9780), Triple("도쿄", 35.6762, 139.6503),
        Triple("뉴욕", 40.7128, -74.0060), Triple("런던", 51.5074, -0.1278),
        Triple("파리", 48.8566, 2.3522),   Triple("홍콩", 22.3193, 114.1694),
        Triple("시드니", -33.8688, 151.2093), Triple("두바이", 25.2048, 55.2708),
        Triple("싱가포르", 1.3521, 103.8198), Triple("LA", 34.0522, -118.2437),
        Triple("베이징", 39.9042, 116.4074), Triple("방콕", 13.7563, 100.5018)
    )
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        cities.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { (name, lat, lng) ->
                    Box(
                        modifier = Modifier.weight(1f).clickable { viewModel.updateCoordName(name); viewModel.updateCoordLat(lat.toString()); viewModel.updateCoordLng(lng.toString()) }
                            .background(GhostColors.BgSurface, RoundedCornerShape(4.dp))
                            .border(1.dp, GhostColors.Border, RoundedCornerShape(4.dp))
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(name, fontSize = 10.sp, color = GhostColors.Cyan, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

private fun formatTimer(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return if (m > 0) "${m}분 ${s}초" else "${s}초"
}
