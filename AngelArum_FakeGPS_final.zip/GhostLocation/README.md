# 👻 Ghost Location — GPS 위치 변조 앱

> **완전 무료, 광고 없음, 오픈소스**  
> Android 8.0 (API 26) 이상 지원

---

## ✨ 주요 기능

| 기능 | 설명 |
|------|------|
| 📍 **지도에서 위치 선택** | OpenStreetMap 탭으로 원하는 위치 즉시 선택 |
| 🔍 **주소/장소명 검색** | "에펠탑", "서울역" 등 자연어 검색 지원 |
| ⌨️ **좌표 직접 입력** | 위도/경도 수동 입력 + 12개 주요 도시 빠른 선택 |
| 📍 **내 실제 위치로 복귀** | 원터치로 실제 GPS 위치로 즉시 복귀 |
| ⭐ **즐겨찾기** | 자주 쓰는 위치 저장 및 즉시 변조 실행 |
| 🕓 **이동 히스토리** | 최근 30개 변조 위치 자동 기록 |
| 🛤️ **경로 시뮬레이션** | A→B 이동 경로 설정, 4단계 속도 조절 |
| 🎲 **랜덤 위치** | 전세계 랜덤 좌표 생성 (테스트용) |
| 🚶 **반경 랜덤 워킹** | 현재 위치 기준 반경 내 자동 랜덤 이동 경로 생성 |
| ⏰ **자동 중지 타이머** | 5분/15분/30분/1시간 후 자동 변조 해제 |

---

## 🛠 설치 방법

### 1단계: Android Studio에서 빌드

```
1. Android Studio 최신 버전 설치
2. 이 프로젝트 폴더를 열기 (Open Project)
3. 상단 메뉴 → Build → Generate Signed APK
   또는 그냥 Run ▶ 버튼으로 USB 연결된 폰에 직접 설치
```

### 2단계: 기기 설정 (★ 필수!)

#### 개발자 옵션 활성화
```
설정 → 휴대전화 정보 → 빌드 번호 → 7번 탭
```

#### 모의 위치 앱 설정
```
설정 → 개발자 옵션 → 모의 위치 앱 → Ghost Location 선택
```

### 3단계: 앱 사용
1. 앱 실행 후 위치 권한 허용
2. 지도에서 원하는 위치 탭 OR 검색
3. **"▶ 변조 시작"** 버튼 누르기
4. 다른 앱(카카오맵, 배달앱 등)에서 가짜 위치 확인

---

## 📱 화면 구성

```
┌─────────────────────────────────┐
│  👻 GHOST LOCATION    [상태바]   │  ← 탑바 (변조 중 네온그린 표시)
├─────────────────────────────────┤
│                                 │
│     OpenStreetMap 지도           │  ← 탭해서 위치 선택
│                        [🔍]    │
│                        [✏️]    │  ← 우상단: 검색/좌표입력/랜덤/내위치
│                        [🎲]    │
│                        [📍]    │
│                                 │
├─────────────────────────────────┤
│  선택된 위치 카드 (좌표 표시)      │
├─────────────────────────────────┤
│  [▶ 변조 시작]  [📍 내 위치]     │  ← 컨트롤 패널
│  ● INACTIVE    ⏰ 자동중지: OFF  │
├─────┬─────┬─────────┬───────────┤
│ 지도 │ 경로 │ 즐겨찾기 │ 히스토리  │  ← 하단 탭
└─────┴─────┴─────────┴───────────┘
```

---

## ⚠️ 주의사항

- **Play Store 배포 불가** — Google 정책상 위치 변조 앱은 배포 금지
- **개인 사용 목적으로만** 사용하세요
- 일부 앱(포켓몬고, 금융앱 등)은 Mock Location 감지 기능이 있어 차단될 수 있음
- 배터리 절약 모드에서는 위치 정확도가 낮아질 수 있음

---

## 🏗 기술 스택

- **Kotlin** + **Jetpack Compose** (최신 UI)
- **MapLibre Android** (OpenStreetMap, 완전 무료)
- **Android ForegroundService** (백그라운드 위치 유지)
- **DataStore Preferences** (즐겨찾기/히스토리 영구 저장)
- **Geocoder API** (주소 검색)
- **Material3** + 커스텀 사이버펑크 테마

---

## 📂 프로젝트 구조

```
GhostLocation/
├── app/src/main/java/com/ghostlocation/
│   ├── MainActivity.kt          # 앱 진입점, 4탭 네비게이션
│   ├── data/
│   │   ├── Models.kt            # 데이터 모델 (GhostLocation, HistoryEntry 등)
│   │   └── PreferencesRepository.kt  # DataStore 저장소
│   ├── service/
│   │   └── MockLocationService.kt    # ★ 핵심: GPS 변조 서비스
│   ├── ui/
│   │   ├── MainViewModel.kt     # 앱 상태 관리
│   │   ├── theme/Theme.kt       # 사이버펑크 색상/타이포그래피
│   │   ├── components/Components.kt  # 재사용 UI 컴포넌트
│   │   └── screens/
│   │       ├── MapScreen.kt     # 지도 탭
│   │       ├── RouteScreen.kt   # 경로 탭
│   │       ├── FavoritesScreen.kt    # 즐겨찾기 탭
│   │       └── HistoryScreen.kt      # 히스토리 탭
│   └── utils/
│       └── LocationHelper.kt    # 실제 GPS, 주소검색, 랜덤위치 유틸
└── app/src/main/AndroidManifest.xml
```

---

*Made with ❤️ — 광고 없는 깔끔한 앱*
